from setuptools import setup
setup(
    name='luis_maria_gomez_paquete',
    version='0.0.0',
    description='Paquete de prueba',
    author='Luis Maria Gomez',
    author_email='chuni12gomez@gmail.com',
    packages=['paquete']
)